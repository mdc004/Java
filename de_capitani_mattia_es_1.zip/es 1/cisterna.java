public class cisterna {
    int identificativo;
    int capacita;
    int stato;

    cisterna(int identificativo, int capacita){
        this.identificativo= identificativo;
        this.capacita = capacita;
    }
    cisterna(int identificativo, int capacita, int stato){
        this.identificativo= identificativo;
        this.capacita = capacita;
        this.stato = stato;

    }

    public int getId() {
        return identificativo;
    }

    public int getCapacita() {
        return capacita;
    }

    public int getStato() {
        return stato;
    }

    public boolean aggiungiValore(int quantita){
        if(stato+quantita>capacita){
            System.out.println("Cisterna piena");
            stato=capacita;
            return false;
        }
        else {
            stato+=quantita;
            return true;
        }
    }

    public int togliValore(int quantita) {
        if(quantita>stato){
            stato=0;
            System.out.println("Livello troppo basso");
            return stato;
        }
        else {
            stato-=quantita;
            return stato;
        }
    }

    public boolean equivalente(cisterna c) {
        if(capacita-stato==c.getCapacita()-c.getStato())return true;       
    }

}
