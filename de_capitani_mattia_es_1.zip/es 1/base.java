import javax.swing.JOptionPane;

/**
 * base
 */
public class base {

    public static void main(String[] args) {
        int identificativo = Integer.parseInt(JOptionPane.showInputDialog("Inserire l'identificativo della cisterna"));
        int capacita = Integer.parseInt(JOptionPane.showInputDialog("Inserire la capacita'"));
        int stato = Integer.parseInt(JOptionPane.showInputDialog("Inserire la quantita'"));
        boolean allarme = false; 
        int livello_soglia = Integer.parseInt(JOptionPane.showInputDialog("Inserire il livello di aqttivazione dell'allarme"));
        cisterna_con_allarme c1= new cisterna_con_allarme(identificativo, capacita, stato, allarme, livello_soglia);
        c1.aggiungiValore(Integer.parseInt(JOptionPane.showInputDialog("Inserire la capacita'")));
        c1.attiva_allarme();
        if(c1.allarme==true)c1.spegniallarme();
    }
    
}