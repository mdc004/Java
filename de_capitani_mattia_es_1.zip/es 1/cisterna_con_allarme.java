public class cisterna_con_allarme extends cisterna{
    boolean allarme = false;
    int livello_soglia;

    cisterna_con_allarme(int identificativo, int capacita, int stato, boolean allarme, int livello_soglia){
        super(identificativo, capacita, stato);
        this.allarme = allarme;
        this.livello_soglia = livello_soglia;
    }

    public void attiva_allarme() {
        if(super.stato>livello_soglia)allarme = true;
    }

    public String stampa() {
        return ("Identificativo cisterna: "+super.identificativo+"\nCapacita' cisterna: "+super.capacita+"\nLivello del materiale: "+super.stato+"\nAllarme: "+allarme+"\nLivello attivazione allarme: "+livello_soglia);
    }

    public void spegniallarme() {
        allarme = false;
        super.stato = 0;
    }
}
