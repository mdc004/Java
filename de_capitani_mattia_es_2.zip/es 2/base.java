import javax.swing.JOptionPane;

/**
 * base
 */
public class base {

    public static void main(String[] args) {
        int n1 = Integer.parseInt(JOptionPane.showInputDialog("Inserire il primo numero"));
        int n2 = Integer.parseInt(JOptionPane.showInputDialog("Inserire il secondo numero"));
        System.out.println("L' MCD dei numeri inseriti e': "+math1.MCD(n1, n2));
    }
}