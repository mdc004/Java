public class math1 {
    public static int MCD(int n1, int n2) {
        int mcd = 0, q=0;
        if(n1<n2){
            int divisori[] = new int[n1];
            for (int i = 0; i < n1; i++) {
                if(n1%i==0){
                    divisori[q]=i;
                    q++;
                }
            }
            do {
                if (n2 % divisori[q] == 0)mcd = divisori[q];
                else
                    q--;
            } 
            while (mcd == 0);
        }
        else{
            int divisori[] = new int[n2];
            for (int i = 0; i < n2; i++) {
                if(n2%i==0){
                    divisori[q]=i;
                    q++;
            }
            do {
                if(n1%divisori[q]==0) mcd= divisori[q];
                else q--;
            } 
            while (mcd==0);
        }
        return mcd;
        }
    }
}