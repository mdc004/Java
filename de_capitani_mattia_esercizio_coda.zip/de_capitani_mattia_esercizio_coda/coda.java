import java.util.ArrayList;
import javax.swing.JOptionPane;

public class coda {
    private ArrayList<piatto> ar;

    public coda() {
        ar = new ArrayList<piatto>();
    }

    public void aggiungi() {
        String descrizione = JOptionPane.showInputDialog("inserisci la descrizione del piatto");
        String tipo = JOptionPane.showInputDialog("inserisci il tipo di piatto");
        double prezzo = Double.parseDouble(JOptionPane.showInputDialog("inserisci il prezzo"));
        piatto temp = new piatto(descrizione, tipo, prezzo);
        ar.add(temp);
    }

    public piatto togli() {
        piatto temp = null;
        if (ar.size() == 0)
            System.out.println("vuoto");
        else {
            temp = ar.get(0);
            ar.remove(0);
        }
        return (temp);
    }

    public void vuota() {
        ar.clear();
    }

    public int size() {
        int x = ar.size();
        System.out.println(x);
        return ar.size();
    }

    public void stampa() {
        piatto temp;
        System.out.println("Elementi Pila: ");
        for (int i = ar.size() - 1; i >= 0; i--) {
            temp = ar.get(i);
            System.out.println(temp.get_descrizione() + " " + temp.get_tipo() + " " + temp.get_prezzo());
        }
    }

    public void aggiungi(piatto temp) {
        ar.add(temp);
    }

    public void aggiungi_n() {
        int n = Integer.parseInt(JOptionPane.showInputDialog("Quanti elementi si desidera togliere"));  
        for (int i = 0; i < n; i++) {
            togli();
        }      
    }
}
