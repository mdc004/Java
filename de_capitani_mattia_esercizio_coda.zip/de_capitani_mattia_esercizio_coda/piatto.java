public class piatto {
    private String descrizione;
    private String tipo;
    private double prezzo;

    public piatto(String descrizione, String tipo, double prezzo) {
        this.descrizione = descrizione;
        this.tipo = tipo;
        this.prezzo = prezzo;
    }

    public double get_prezzo() {
        return prezzo;
    }

    public String get_descrizione() {
        return descrizione;
    }

    public String get_tipo() {
        return tipo;
    }
}
