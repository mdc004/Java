import javax.swing.JOptionPane;

public class base {
    public static void main(String[] args) {
        int key=0;
        coda c = new coda();
        coda c2 = new coda();
        do{
            key=Integer.parseInt(JOptionPane.showInputDialog("inserisci:"+ 
            "\n 0. per terminare"+ 
            "\n 1. per aggiungere n elementi"+
            "\n 2. per aggiungere un elemento"+
            "\n 3. per estrarre n elementi" +
            "\n 4. per estrarre un solo elemento"+
            "\n 5. per stampare la coda"));
            switch(key){
                case 0: 
                    System.out.println("********Programma Terminato********");
                    break;
                case 1:
                    c.aggiungi_n(); //n elementi
                    break;
                case 2:
                    c.aggiungi(); //un elemento
                    break;
                case 3:
                    int n = Integer.parseInt(JOptionPane.showInputDialog("Quanti elementi si desidera aggiungere"));
                    for (int i = 0; i < n; i++) {
                        c2.aggiungi(c.togli());
                    }
                    break;
                case 4:
                    c2.aggiungi(c.togli());
                    break;
                case 5 :
                    c.stampa();
                    break;
            }
        }
        while(key!=0);
    }
}

