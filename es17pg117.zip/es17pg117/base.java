import java.util.ArrayList;
import javax.swing.JOptionPane;

/* 
    prezzo e quantità in l distributori 
        inserire l distributori (tutto dall'esterno)
        inserire un distributore in testa
        calcolare max min media
        cancellare i distributori che hanno meno di x litri
        stampa
        ai distributori con prezzo maggiore della media diminuisce prezzo del 10
*/

public class base {
    public static void main(String[] args) {
        ArrayList<distributore> distributori = new ArrayList<distributore>();
        int l,key;
        do {
            // Scelta
            key = Integer.parseInt(JOptionPane.showInputDialog("Premere:"+
                "\n0. Per terminare il programma"+
                "\n1. Per inserire il numero di distributori desiderato"+
                "\n2. Per conoscere il prezzo medio del carburante e i distributori con il prezzo massimo e minimo"+
                "\n3. Per inserire un distributore all'inizio dell'array"+
                "\n4. Per eliminare i distributori con un prezzo inferiore a quello inserito da tastiera"+
                "\n5. Per diminuire del 10% il prezzo dei distributori con un prezzo inferiore al prezzo medio"+
                "\n6. Per conoscere i distributori memorizzati\n"
            ));
            switch (key) {
                case 0:
                    // Uscita
                    System.out.println("*********Programma Terminato*********");
                    break;
                case 1:
                    // Inserimento
                    l = Integer.parseInt(JOptionPane.showInputDialog("Inserire la quantita' di distributori che si desidera inserire"));
                    for (int i = 0; i < l; i++) {
                        String nome = (JOptionPane.showInputDialog("Inserire il nome del distributore che si desidera inserire"));
                        Double prezzo = Double.parseDouble(JOptionPane.showInputDialog("Inserire il prezzo del carburante nel distributore "+nome));
                        Double quantita = Double.parseDouble(JOptionPane.showInputDialog("Inserire la quantita' carburante presente nel distributore "+nome));
                        distributore q = new distributore(nome, prezzo, quantita);
                        distributori.add(q);
                    }
                    break;
                case 2:
                    // Media maggiore minore
                    double somma=0;
                    int pos_min = 0, pos_max = 0;    
                    for (int i = 0; i < distributori.size(); i++) {
                        // Variabile di supporto
                        double temp = distributori.get(i).getPrezzo();
                        // Maggiore minore
                        if(temp>distributori.get(pos_max).getPrezzo())pos_max = i;
                        if(temp<distributori.get(pos_min).getPrezzo())pos_min = i;
                        // Somma per media
                        somma+=temp;
                    }
                    // Calcolo media
                    double media = somma/distributori.size();
                    JOptionPane.showMessageDialog(null, "La media del prezzo del carburante e' "+media);
                    JOptionPane.showMessageDialog(null, "Il distributore con prezzo del carburante minore e' "+distributori.get(pos_min).getPrezzo()+" con prezzo "+distributori.get(pos_min).getNome());
                    JOptionPane.showMessageDialog(null, "Il distributore con prezzo del carburante maggiore e' "+distributori.get(pos_max).getPrezzo()+" con prezzo "+distributori.get(pos_max).getNome());
                    break;
                case 3:
                    // Aggiunge un distributore all'inizio
                    String nome = (JOptionPane.showInputDialog("Inserire il nome del distributore che si desidera inserire all'inizio dell'array"));
                    Double prezzo = Double.parseDouble(JOptionPane.showInputDialog("Inserire il prezzo del carburante nel distributore "+nome));
                    Double quantita = Double.parseDouble(JOptionPane.showInputDialog("Inserire la quantita' carburante presente nel distributore "+nome));
                    distributore q = new distributore(nome, prezzo, quantita);
                    distributori.add(0,q);
                    break;
                case 4:
                    // Elimina i distributori con prezzo sotto x
                    double x = Double.parseDouble(JOptionPane.showInputDialog("Inserire il prezzo sotto al quale eliminare i distributori"));
                    for (int i = 0; i < distributori.size(); i++) {
                        if(distributori.get(i).getPrezzo()<x)distributori.remove(i);
                    }
                    break;
                case 5:   
                    // Sconta del 10 i distributori con prezzo sopra la media
                    // Ricalcolo la media nel caso non sia stata calcolata precedentemente
                    somma = 0;
                    for (int i = 0; i < distributori.size(); i++) {
                        somma += distributori.get(i).getPrezzo();
                    }
                    media = somma / distributori.size();
                    // Controllo se il prezzo del distributore di posto i sia maggiore della media
                    for (int i = 0; i < distributori.size(); i++) {
                        if (distributori.get(i).getPrezzo()>media)distributori.get(i).setPrezzo((distributori.get(i).getPrezzo())*0.9);
                    }
                    break;
                case 6: 
                    // Stampa
                    for (int i = 0; i < distributori.size(); i++) {
                        JOptionPane.showMessageDialog(null, "Distributore "+ distributori.get(i).getNome()+"\nPrezzo del carburante al litro "+distributori.get(i).getPrezzo()+"\nLa quantita' di carburante residua e' pari a "+distributori.get(i).getQuantita());
                    }
            }
        } while (key!=0);
    }
}