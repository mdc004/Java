public class distributore {
    private String nome;
    private double prezzo;
    private double quantita;
    
    public distributore(String nome, double prezzo, double quantita){
        this.nome = nome;
        this.prezzo = prezzo;
        this.quantita = quantita;
    } 

    public double getPrezzo() {
        return prezzo;
    }

    public String getNome() {
        return nome;
    }
    public double getQuantita() {
        return quantita;
    }

    public void setPrezzo(double prezzo) {
        this.prezzo = prezzo;
    }
}
